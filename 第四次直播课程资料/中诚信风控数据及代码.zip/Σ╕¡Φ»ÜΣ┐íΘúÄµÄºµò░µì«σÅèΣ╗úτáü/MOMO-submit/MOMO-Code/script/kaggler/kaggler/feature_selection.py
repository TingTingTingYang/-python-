# -*- coding: utf-8 -*-
from __future__ import print_function

from sklearn.feature_selection import *
from sklearn.metrics import make_scorer

# VarianceThreshold, chi2, f_classif, f_regression, mutual_info_classif, mutual_info_regression
class FilterSelection():
    def __init__(self):
        pass

    def fit(self, data, label, filter_func):
        if isinstance(filter_func, VarianceThreshold):
            self.mask = filter_func.fit(data).variances_
        else:
            self.mask = filter_func(data, label)[0]
        return self.mask

    # Canrot user for VarianceThreshold
    def select_best(self, data, label, select_func):
        return select_func.fit(data, label).get_support()

class WrapperSelection():
    def __init__(self, filter_func):
        self.filter_func = filter_func

    def fit(self, data, label, n_features):
        return RFE(estimator = self.filter_func, n_features_to_select = n_features
            ).fit(data, label).get_support()

    def fitcv(self, data, label, eval_func, verbose = 0):
        return RFECV(estimator = self.filter_func, scoring = make_scorer(eval_func),
                verbose = verbose).fit(data, label).get_support()

class EmbeddedSelection():
    def __init__(self, filter_func):
        self.filter_func = filter_func

    def fit(self, data, label):
        return SelectFromModel(self.filter_func).fit(data, label).get_support()
