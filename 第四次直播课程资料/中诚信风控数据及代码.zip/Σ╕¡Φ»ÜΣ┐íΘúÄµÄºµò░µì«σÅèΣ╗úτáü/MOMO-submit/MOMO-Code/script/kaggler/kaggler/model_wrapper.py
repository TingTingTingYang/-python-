# -*- coding: utf-8 -*-
from __future__ import print_function

import time
import datetime
import numpy as np

import xgboost as xgb
import lightgbm as lgb
# from bayes_opt import BayesianOptimization

from .utils import *

class SklearnWrapper(object):
    def __init__(self, clf, params = None):
        if params:
            self.clf = clf(**params)
        else:
            self.clf = clf

    def fit(self, X_train, y_train, X_val = None, y_val = None, eval_func = None):
        self.clf.fit(X_train, y_train)

    def predict_proba(self, x):
        proba = self.clf.predict_proba(x)
        return proba

    def predict(self, x):
        return self.clf.predict(x)

    def optimize(self, X_train, y_train, X_eval, y_eval, param_grid, eval_func, is_proba):
        def fun(**params):
            for k in params:
                if type(param_grid[k][0]) is int:
                    params[k] = int(params[k])

            self.clf.set_params(**params)
            self.fit(X_train, y_train)

            if is_proba:
                p_eval = self.predict_proba(X_eval)
            else:
                p_eval = self.predict(X_eval)

            best_score = eval_func(y_eval, p_eval)

            return -best_score

        opt = BayesianOptimization(fun, param_grid)
        opt.maximize(n_iter = 100)

        print ("Best mae: %.5f, params: %s" % (opt.res['max']['max_val'], opt.res['max']['max_params']))

    def get_name(self):
        return self.clf.__class__.__name__

class XgbWrapper(object):
    def __init__(self, params):
        self.param = params

    def fit(self, X_train, y_train, X_val = None, y_val = None, num_round = 100000, feval = None):
        dtrain = xgb.DMatrix(X_train, label = y_train)

        if X_val is None:
            watchlist = [(dtrain, 'train')]
        else:
            deval = xgb.DMatrix(X_val, label = y_val)
            watchlist = [(dtrain, 'train'), (deval, 'val')]
        
        if feval is None:
            self.clf = xgb.train(self.param, dtrain, num_round, evals = watchlist, verbose_eval = 200, early_stopping_rounds = 100, )
        else:
            self.clf = xgb.train(self.param, dtrain, num_round, evals = watchlist, feval = feval, verbose_eval = 200, early_stopping_rounds = 100)

    def predict_proba(self, x):
        return self.clf.predict(xgb.DMatrix(x))

    def predict(self, x):
        return self.clf.predict(xgb.DMatrix(x))

    def optimize(self, X_train, y_train, param_grid, eval_func = None, is_proba = False, seed = 42):
        feval = lambda y_pred, y_true: ('mae', eval_func(y_true.get_label(), y_pred))

        dtrain = xgb.DMatrix(X_train, label = y_train)

        def fun(**kw):
            params = self.param.copy()
            params['seed'] = seed

            for k in kw:
                if type(param_grid[k][0]) is int:
                    params[k] = int(kw[k])
                else:
                    params[k] = kw[k]

            model = xgb.cv(params, dtrain, 100000, 5, feval = feval, verbose_eval = None, early_stopping_rounds = 100)

            return - model['test-mae-mean'].values[-1]

        opt = BayesianOptimization(fun, param_grid)
        opt.maximize(n_iter = 100)

        print("Best mae: {0:0.5f}, params: {1}".format(opt.res['max']['max_val'], opt.res['max']['max_params']))

    def get_name(self):
        return 'XGBoost'

class GbmWrapper(object):
    def __init__(self, clf, params = None):
        if params:
            self.clf = clf(**params)
        else:
            self.clf = clf

    def fit(self, X_train, y_train, X_val, y_val , eval_func = None):
        self.clf.fit(X_train, y_train, eval_set = [(X_val, y_val)], early_stopping_rounds = 500, verbose = False)

    def predict_proba(self, x):
        return self.clf.predict_proba(x)

    def predict(self, x):
        return self.clf.predict(x)

    def get_name(self):
        return 'lightGBM'

    # TODO
    def optimize(self, X_train, y_train, X_eval, y_eval, param_grid, eval_func, is_proba):
        def fun(**params):
            for k in params:
                if type(param_grid[k][0]) is int:
                    params[k] = int(params[k])

            self.clf.set_params(**params)
            self.fit(X_train, y_train)

            if is_proba:
                p_eval = self.predict_proba(X_eval)
            else:
                p_eval = self.predict(X_eval)

            best_score = eval_func(y_eval, p_eval)

            return -best_score
        opt = BayesianOptimization(fun, param_grid)
        opt.maximize(n_iter = 500)

        print ("Best mae: %.5f, params: %s" % (opt.res['max']['max_val'], opt.res['max']['max_params']))

class RgfWrapper(object):
    def __init__(self, clf, params = None):
        if params:
            self.param = params
            self.clf = clf(**params)
        else:
            self.clf = clf

    def fit(self, X_train, y_train, X_val = None, y_val = None, eval_func = None):
        self.clf.fit(X_train, y_train)

    def predict_proba(self, x):
        return self.clf.predict_proba(x)

    def predict(self):
        return self.clf.predict(x)

    def get_name(self):
        return 'RegularizedGreedyForest'

class KerasWrapper():

    def __init__(self, arch, params, scale=True, loss='mae', checkpoint=False):
        self.arch = arch
        self.params = params
        self.scale = scale
        self.loss = loss
        self.checkpoint = checkpoint

    def fit(self, X_train, y_train, X_eval = None, y_eval = None, eval_func = None):
        if self.scale:
            self.scaler = StandardScaler(with_mean=False)

            X_train = self.scaler.fit_transform(X_train)

            if X_eval is not None:
                X_eval = self.scaler.transform(X_eval)

        checkpoint_path = "/tmp/nn-weights-%d.h5" % seed

        self.model = self.arch((X_train.shape[1],), params)
        self.model.compile(optimizer=params.get('optimizer', 'adadelta'), loss = self.loss)

        callbacks = list(params.get('callbacks', []))

        if self.checkpoint:
            callbacks.append(ModelCheckpoint(checkpoint_path, monitor='val_loss', save_best_only=True, verbose=0))

        self.model.fit_generator(
            generator = batch_generator(X_train, y_train, params['batch_size'], True), samples_per_epoch=X_train.shape[0],
            validation_data = batch_generator(X_eval, y_eval, 800) if X_eval is not None else None, nb_val_samples=X_eval.shape[0] if X_eval is not None else None,
            nb_epoch = params['n_epoch'], verbose=1, callbacks=callbacks)

        if self.checkpoint and os.path.isfile(checkpoint_path):
            self.model.load_weights(checkpoint_path)

    def predict(self, X):
        if self.scale:
            X = self.scaler.transform(X)

        return self.model.predict_generator(batch_generator(X, batch_size=800), val_samples = X.shape[0]).reshape((X.shape[0],))

    def get_name(self):
        return 'NN'

class LibFmWrapper():
    def __init__(self, clf, params = None):
        if params:
            self.clf = clf(**params)
        else:
            self.clf = clf

    def fit(self, X_train, y_train, X_eval = None, y_eval = None, eval_func = None):
        self.clf.run(X_train, y_train, X_val, y_val)

    def predict(self):
        return self.clf.predictions

    def get_name(self):
        return 'LibFM'

# t-SNE/SVD
class EmbeddingWrapper():
    def __init__(self, clf, params = None):
        if params:
            self.clf = clf(**params)
        else:
            self.clf = clf

    def fit_transform(self, X):
        return self.clf.fit_transform(X)

    def get_name(self):
        return self.clf.__class__.__name__
